import os, re
from urllib.parse import urlparse
import requests
from bs4 import BeautifulSoup
from dotenv import load_dotenv
from flask import Flask, jsonify, render_template, request
load_dotenv()
app=Flask(__name__)
SAMPLES=[
{'id':'sample-1','title':'How AI Is Changing Everyday Work','description':'A practical look at how artificial intelligence tools are changing research, writing, and productivity.','url':'https://example.com/ai-everyday-work','source':'ArticleHub Demo','category':'Technology','publishedAt':'2026-10-20T09:00:00Z','content':'AI tools can support research, summarize information, and automate repetitive tasks. Good results still depend on human review, clear goals, and responsible use.'},
{'id':'sample-2','title':'Simple Habits for a More Sustainable City','description':'Small changes in transport, energy use, and waste can make urban life more sustainable.','url':'https://example.com/sustainable-city','source':'ArticleHub Demo','category':'Environment','publishedAt':'2026-10-18T11:30:00Z','content':'Cities can reduce their footprint through public transport, walking, cycling, efficient buildings, and better waste systems.'},
{'id':'sample-3','title':'The Basics of Personal Cybersecurity','description':'Learn the essentials: unique passwords, multi-factor authentication, software updates, and phishing awareness.','url':'https://example.com/personal-cybersecurity','source':'ArticleHub Demo','category':'Technology','publishedAt':'2026-10-15T08:15:00Z','content':'Use a password manager, enable multi-factor authentication, keep software updated, and verify unexpected links.'},
{'id':'sample-4','title':'Why Local Food Systems Matter','description':'Local food networks can connect growers and communities while improving food resilience.','url':'https://example.com/local-food','source':'ArticleHub Demo','category':'Lifestyle','publishedAt':'2026-10-12T14:00:00Z','content':'Farmers markets, community gardens, and regional supply chains can help communities understand where food comes from.'}]
def clean(s): return re.sub(r'\s+',' ',s or '').strip()
def extract(url):
 p=urlparse(url)
 if p.scheme not in ('http','https') or not p.netloc: raise ValueError('Enter a complete http:// or https:// URL.')
 if (p.hostname or '').lower() in {'localhost','127.0.0.1','::1'} or (p.hostname or '').endswith('.local'): raise ValueError('Local URLs are not supported.')
 r=requests.get(url,timeout=12,headers={'User-Agent':'ArticleHubStudentProject/1.0'}); r.raise_for_status(); soup=BeautifulSoup(r.text,'html.parser')
 for t in soup(['script','style','noscript','nav','footer','header','aside']): t.decompose()
 def meta(**attrs):
  t=soup.find('meta',attrs=attrs); return clean(t.get('content')) if t and t.get('content') else ''
 title=meta(property='og:title') or (clean(soup.title.get_text()) if soup.title else '') or p.netloc
 desc=meta(name='description') or meta(property='og:description'); image=meta(property='og:image')
 node=soup.find('article') or soup.find('main') or soup.body or soup
 paragraphs=[clean(x.get_text(' ',strip=True)) for x in node.find_all('p')]; content=' '.join(x for x in paragraphs if len(x)>35)[:12000]
 return {'id':'scraped-'+str(abs(hash(url))),'title':title[:250],'description':(desc or content[:260] or 'No description found.')[:500],'url':url,'source':p.netloc,'category':'Scraped','publishedAt':'','image':image,'content':content or desc}
@app.get('/')
def home(): return render_template('index.html')
@app.get('/api/health')
def health(): return jsonify(status='ok',service='ArticleHub API')
@app.get('/api/articles')
def articles():
 q=clean(request.args.get('q','')).lower(); cat=clean(request.args.get('category','')).lower()
 items=[a for a in SAMPLES if (not q or q in (a['title']+' '+a['description']+' '+a['content']+' '+a['source']).lower()) and (not cat or cat=='all' or a['category'].lower()==cat)]
 return jsonify(articles=items,count=len(items),mode='sample-data')
@app.post('/api/scrape')
def scrape():
 url=clean((request.get_json(silent=True) or {}).get('url',''))
 if not url: return jsonify(error='Please provide an article URL.'),400
 try: return jsonify(article=extract(url))
 except ValueError as e: return jsonify(error=str(e)),400
 except requests.RequestException as e: return jsonify(error='Could not fetch page ('+e.__class__.__name__+'). Check URL and try again.'),422
 except Exception: app.logger.exception('Scraping error'); return jsonify(error='Article extraction failed.'),500
@app.get('/api/guardian')
def guardian():
 key=os.getenv('GUARDIAN_API_KEY','').strip()
 if not key: return jsonify(error='Guardian API not configured. Add GUARDIAN_API_KEY to environment.'),503
 params={'api-key':key,'page-size':12,'show-fields':'trailText,thumbnail,bodyText'}; q=clean(request.args.get('q',''))
 if q: params['q']=q
 try:
  data=requests.get('https://content.guardianapis.com/search',params=params,timeout=12); data.raise_for_status(); items=[]
  for x in data.json().get('response',{}).get('results',[]):
   f=x.get('fields',{}); items.append({'id':x.get('id'),'title':x.get('webTitle'),'description':clean(f.get('trailText','')),'url':x.get('webUrl'),'source':'The Guardian','category':x.get('sectionName','News'),'publishedAt':x.get('webPublicationDate',''),'image':f.get('thumbnail',''),'content':clean(f.get('bodyText',''))[:12000]})
  return jsonify(articles=items,count=len(items),mode='guardian-api')
 except requests.RequestException: return jsonify(error='Guardian API request failed.'),502
if __name__=='__main__': app.run(host='0.0.0.0',port=int(os.getenv('PORT','5000')),debug=os.getenv('FLASK_DEBUG','false').lower()=='true')
