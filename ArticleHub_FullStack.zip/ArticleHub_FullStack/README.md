# ArticleHub — Full-Stack Article Web Scraping Project

Student project using HTML, CSS, JavaScript, Python Flask, Requests, and BeautifulSoup.

## Features
- Responsive frontend served by Flask
- Search/filter sample articles
- Save/remove articles in browser localStorage
- Extract title, description, image metadata, and paragraphs from a public article URL
- Optional Guardian Content API endpoint
- Health-check endpoint

## Run locally (Windows / VS Code)
1. Install Python 3.12 and open this folder in VS Code.
2. In Terminal:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
Copy-Item .env.example .env
python app.py
```

If activation is blocked, run `\.venv\Scripts\python.exe -m pip install -r requirements.txt` and then `\.venv\Scripts\python.exe app.py`.

3. Open http://127.0.0.1:5000. Health endpoint: http://127.0.0.1:5000/api/health

## Optional Guardian API
No Guardian API request is made on startup. The request only occurs when you explicitly visit `/api/guardian`. Add your key to `.env` as `GUARDIAN_API_KEY=your_key`, restart the server, then visit `http://127.0.0.1:5000/api/guardian?q=technology`. Never put the key in frontend JavaScript or commit `.env`.

## Deploy the full-stack app
A static-only Netlify site cannot run Python Flask. Deploy this full-stack version to Render:
1. Upload the project contents (not the ZIP itself) to a GitHub repository.
2. Create a Render Web Service from that repository.
3. Use build command `pip install -r requirements.txt` and start command `gunicorn app:app` (`render.yaml` is included).
4. Deploy; frontend and API use the same Render URL.

## Endpoints
- `GET /` frontend
- `GET /api/health` health check
- `GET /api/articles?q=ai&category=Technology` sample feed
- `POST /api/scrape` JSON body `{"url":"https://example.com"}`
- `GET /api/guardian?q=technology` optional Guardian integration

## Notes
Sample feed is hard-coded. Scraping is best-effort and may fail on sites that block requests or use dynamic rendering. Respect site terms, robots policies, copyright, and rate limits. Saved articles remain in the current browser only; this starter has no database, authentication, or scheduled crawler.
